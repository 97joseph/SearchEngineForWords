# cs3219-kwic
KWIC
![Screenshot](http://i.imgur.com/XJ4eHrz.png)
